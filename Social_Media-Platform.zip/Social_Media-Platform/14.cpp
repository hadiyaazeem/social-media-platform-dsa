#include <iostream>
#include <string>
using namespace std;

// AVL TREE NODE
// Each node stores a key (string) and a value (int).
// Used to track users (by activity) and posts (by likes).
struct AVLNode {
    string key;
    int value;
    AVLNode* left;
    AVLNode* right;
    int height;

    AVLNode(string k, int v) {
        key = k; value = v;
        left = right = nullptr;
        height = 1;
    }
};

// AVL TREE CLASS
// Self balancing BST. Keeps data sorted and balanced
// so search, insert, and delete stay O(log n).
class AVLTree {
public:
    AVLNode* root = nullptr;

    // Returns height of a node; 0 if null
    int h(AVLNode* n) { return n ? n->height : 0; }

    // Balance factor = left subtree height - right subtree height
    int balanceFactor(AVLNode* n) { return n ? h(n->left) - h(n->right) : 0; }

    // Right rotation  used when left subtree is heavier
    AVLNode* rotateRight(AVLNode* y) {
        AVLNode* x = y->left;
        AVLNode* T2 = x->right;
        x->right = y; y->left = T2;
        y->height = max(h(y->left), h(y->right)) + 1;
        x->height = max(h(x->left), h(x->right)) + 1;
        return x;
    }

    // Left rotation used when right subtree is heavier
    AVLNode* rotateLeft(AVLNode* x) {
        AVLNode* y = x->right;
        AVLNode* T2 = y->left;
        y->left = x; x->right = T2;
        x->height = max(h(x->left), h(x->right)) + 1;
        y->height = max(h(y->left), h(y->right)) + 1;
        return y;
    }

    // Rebalance the node after insertion or deletion
    AVLNode* balance(AVLNode* node, string key) {
        node->height = 1 + max(h(node->left), h(node->right));
        int bf = balanceFactor(node);
        if (bf > 1 && key < node->left->key)   return rotateRight(node);       // Left-Left
        if (bf < -1 && key > node->right->key)  return rotateLeft(node);        // Right-Right
        if (bf > 1 && key > node->left->key) {                                  // Left-Right
            node->left = rotateLeft(node->left);
            return rotateRight(node);
        }
        if (bf < -1 && key < node->right->key) {                                // Right-Left
            node->right = rotateRight(node->right);
            return rotateLeft(node);
        }
        return node;
    }

    // Insert a new key value pair; if key exists, add to its value
    AVLNode* insert(AVLNode* node, string key, int value) {
        if (!node) return new AVLNode(key, value);
        if (key < node->key)      node->left = insert(node->left, key, value);
        else if (key > node->key) node->right = insert(node->right, key, value);
        else { node->value += value; return node; }
        return balance(node, key);
    }

    // Update the value of an existing node by key
    AVLNode* updateValue(AVLNode* node, string key, int newVal) {
        if (!node) return nullptr;
        if (key < node->key)      node->left = updateValue(node->left, key, newVal);
        else if (key > node->key) node->right = updateValue(node->right, key, newVal);
        else                      node->value = newVal;
        return node;
    }

    void updateValue(string key, int newVal) { root = updateValue(root, key, newVal); }

    // Search for a node by key; returns nullptr if not found
    AVLNode* search(AVLNode* node, string key) {
        if (!node) return nullptr;
        if (key == node->key) return node;
        if (key < node->key)  return search(node->left, key);
        return                       search(node->right, key);
    }

    AVLNode* search(string key) { return search(root, key); }

    // Find the leftmost (minimum value) node in a subtree
    AVLNode* minNode(AVLNode* node) {
        while (node->left) node = node->left;
        return node;
    }

    // Delete a node by key and rebalance the tree
    AVLNode* deleteNode(AVLNode* node, string key) {
        if (!node) return nullptr;
        if (key < node->key)      node->left = deleteNode(node->left, key);
        else if (key > node->key) node->right = deleteNode(node->right, key);
        else {
            // Node with one or no child
            if (!node->left || !node->right) {
                AVLNode* temp = node->left ? node->left : node->right;
                delete node;
                return temp;
            }
            // Node with two children: replace with inorder successor
            AVLNode* temp = minNode(node->right);
            node->key = temp->key;
            node->value = temp->value;
            node->right = deleteNode(node->right, temp->key);
        }
        return balance(node, key);
    }

    void deleteKey(string key) { root = deleteNode(root, key); }

    // In-order traversal prints all nodes in sorted key order
    void inorder(AVLNode* node) {
        if (!node) return;
        inorder(node->left);
        cout << "  " << node->key << " -> " << node->value << endl;
        inorder(node->right);
    }

    void showSorted() {
        if (!root) { cout << "  (empty)" << endl; return; }
        inorder(root);
    }

    // Collect all nodes into an array (used for top-K sorting)
    void collectAll(AVLNode* node, AVLNode** arr, int& cnt) {
        if (!node) return;
        collectAll(node->left, arr, cnt);
        arr[cnt++] = node;
        collectAll(node->right, arr, cnt);
    }

    // Find top K nodes by value using bubble sort
    void getTopK(int k) {
        if (k <= 0) { cout << "  [Error] K must be a positive number." << endl; return; }
        AVLNode* arr[500];
        int cnt = 0;
        collectAll(root, arr, cnt);
        if (cnt == 0) { cout << "  No data available." << endl; return; }
        // Bubble sort descending by value
        for (int i = 0; i < cnt - 1; i++)
            for (int j = 0; j < cnt - i - 1; j++)
                if (arr[j]->value < arr[j + 1]->value)
                    swap(arr[j], arr[j + 1]);
        cout << "  Top " << k << " results:" << endl;
        for (int i = 0; i < k && i < cnt; i++)
            cout << "  " << (i + 1) << ". " << arr[i]->key
            << " (score: " << arr[i]->value << ")" << endl;
    }

    // Print all nodes whose value falls within [minV, maxV]
    void rangeQuery(AVLNode* node, int minV, int maxV) {
        if (!node) return;
        rangeQuery(node->left, minV, maxV);
        if (node->value >= minV && node->value <= maxV)
            cout << "  " << node->key << " -> " << node->value << endl;
        rangeQuery(node->right, minV, maxV);
    }

    void rangeQuery(int minV, int maxV) {
        cout << "  Range [" << minV << " - " << maxV << "]:" << endl;
        rangeQuery(root, minV, maxV);
    }
};
// Global AVL trees: one tracks user activity scores, one tracks post likes
AVLTree userAVL;
AVLTree postAVL;
// POST  stored in a doubly linked list per user
struct Post {
    string postID, content, owner;
    int likes;
    Post* next;
    Post* prev;

    Post(string id, string c, string o) {
        postID = id; content = c; owner = o;
        likes = 0; next = prev = nullptr;
    }
};
// EDGE  one directed connection in the friendship graph
struct Edge {
    string friendUserName;
    Edge* next;
    Edge(string f) { friendUserName = f; next = nullptr; }
};
// STORY stored in a circular linked list per user
struct Story {
    string userName, storyContent;
    Story* next;
    Story(string u, string s) { userName = u; storyContent = s; next = nullptr; }
};

// NOTIFICATION  stored in a global FIFO queue
// forUser field ensures only the intended user sees it
struct Notification {
    string message;
    string forUser;    // Which user this notification belongs to
    string timestamp;
    Notification* next;
    Notification(string m, string u, string t) {
        message = m; forUser = u; timestamp = t; next = nullptr;
    }
};
// MESSAGE  CONVERSATION  stack based messaging
// Latest message sits on top popping removes it

struct Message {
    string fromUser, toUser, text, timestamp;
    Message* next;
    Message(string f, string t, string txt, string ts) {
        fromUser = f; toUser = t; text = txt; timestamp = ts; next = nullptr;
    }
};

struct Conversation {
    string otherUser;
    Message* top;      // Stack top -- most recent message
    Conversation* next;
    Conversation(string other) { otherUser = other; top = nullptr; next = nullptr; }
};
// USER  the core entity of the platform

struct User {
    string userName, password, email, bio, lastActive;
    User* next;              // Next user in the same hash table bucket
    Edge* friendList;        // Adjacency list for the friendship graph
    Post* postHead;          // Head of doubly linked post list
    Story* storyHead;        // Head of circular story list
    Conversation* convList;  // List of conversations (each is a message stack)

    User(string u, string p, string e, string b) {
        userName = u; password = p; email = e; bio = b;
        lastActive = "N/A";
        next = nullptr;
        friendList = nullptr;
        postHead = nullptr;
        storyHead = nullptr;
        convList = nullptr;
    }
};
// GLOBALS
const int TABLE_SIZE = 10;
User* hashTable[TABLE_SIZE];  // Hash table with chaining for O(1) avg lookup
User* currentUser = nullptr;  // Pointer to whoever is currently logged in

Notification* nFront = nullptr;  // Front of the notification queue
Notification* nRear = nullptr;  // Rear of the notification queue

// INPUT HELPERS


// Reads an integer safely; prints error and returns false on bad input
bool readInt(int& out) {
    string raw;
    cin >> raw;
    bool hasDigit = false;
    for (int i = 0; i < (int)raw.size(); i++) {
        if (i == 0 && raw[i] == '-') continue;
        if (raw[i] < '0' || raw[i] > '9') {
            cout << "  [Error] Please enter a valid number." << endl;
            return false;
        }
        hasDigit = true;
    }
    if (!hasDigit) { cout << "  [Error] Please enter a valid number." << endl; return false; }
    out = stoi(raw);
    return true;
}

// Returns true if string has at least one non-space character
bool notEmpty(const string& s) {
    return !s.empty() && s.find_first_not_of(' ') != string::npos;
}
// NOTIFICATION FUNCTIONS
// The global queue holds notifications for all users.
// Every function filters by currentUser->userName so
// users only ever see their own notifications.
// Add a new notification to the back of the queue for a specific user
void pushNotification(string msg, string forUser) {
    Notification* n = new Notification(msg, forUser, "NOW");
    if (!nRear) nFront = nRear = n;
    else { nRear->next = n; nRear = n; }
}

// Look at the current user's earliest notification without removing it
void peekNotification() {
    if (!currentUser) { cout << "  [Error] Not logged in!" << endl; return; }
    Notification* t = nFront;
    while (t) {
        if (t->forUser == currentUser->userName) {
            cout << "  Next notification: " << t->message
                << " (" << t->timestamp << ")" << endl;
            return;
        }
        t = t->next;
    }
    cout << "  No notifications for you." << endl;
}
// Print all notifications that belong to the current user
void showNotifications() {
    if (!currentUser) { cout << "  [Error] Not logged in!" << endl; return; }
    cout << endl << "{NOTIFICATIONS for " << currentUser->userName << " }" << endl;
    bool found = false;
    Notification* t = nFront;
    while (t) {
        if (t->forUser == currentUser->userName) {
            cout << "  - " << t->message << " (" << t->timestamp << ")" << endl;
            found = true;
        }
        t = t->next;
    }
    if (!found) cout << "  No notifications for you." << endl;
}

// Remove and process the current user's earliest notification
void popNotification() {
    if (!currentUser) { cout << "  [Error] Not logged in!" << endl; return; }
    Notification* prev = nullptr;
    Notification* t = nFront;
    while (t) {
        if (t->forUser == currentUser->userName) {
            cout << "  Processed: " << t->message << endl;
            if (prev) prev->next = t->next;
            else      nFront = t->next;
            if (t == nRear) nRear = prev;
            delete t;
            return;
        }
        prev = t;
        t = t->next;
    }
    cout << "  No notifications to process." << endl;
}
// HASH FUNCTION
// Sums ASCII values of all characters, mod TABLE_SIZE.
// Simple but effective for string keys.
int hashFunction(string key) {
    int sum = 0;
    for (char c : key) sum += c;
    return sum % TABLE_SIZE;
}

// Clears the hash table and pre-loads 5 users so you
// can log in immediately without registering.
//
//   Username  | Password
//   ----------|-----------
//   saleha    | saleha123
//   fiza      | fiza456
//   areesha   | areesha789
//   asma      | asma321
//   ayesha    | ayesha000

void init() {
    // Initialize all hash table slots to null
    for (int i = 0; i < TABLE_SIZE; i++) hashTable[i] = nullptr;

    // Pre-registered user data (username, password, email, bio)
    struct PreUser { const char* u; const char* p; const char* e; const char* b; };
    PreUser defaults[] = {
        { "saleha",  "saleha123",  "saleha@gmail.com",  "CS student, chai lover, coding enthusiast."     },
        { "fiza",    "fiza456",    "fiza@gmail.com",    "Designer at heart, always sketching ideas."     },
        { "areesha", "areesha789", "areesha@gmail.com", "Bookworm. Sunsets and novels -- life sorted."   },
        { "asma",    "asma321",    "asma@gmail.com",    "Foodie + traveller. Biryani > everything."      },
        { "ayesha",  "ayesha000",  "ayesha@gmail.com",  "Music, coffee, and late night coding sessions." }
    };

    // Insert each pre-registered user into the hash table and the userAVL tree
    for (int i = 0; i < 5; i++) {
        User* nu = new User(defaults[i].u, defaults[i].p, defaults[i].e, defaults[i].b);
        nu->lastActive = "Pre registered";
        int idx = hashFunction(defaults[i].u);
        nu->next = hashTable[idx];
        hashTable[idx] = nu;
        userAVL.root = userAVL.insert(userAVL.root, defaults[i].u, 0);
    }


}

// Search the hash table for a user by username; returns nullptr if not found
User* searchUser(string name) {
    int idx = hashFunction(name);
    User* t = hashTable[idx];
    while (t) { if (t->userName == name) return t; t = t->next; }
    return nullptr;
}
// MODULE H: CLEANUP
// Called when a user deletes their account.
// Frees all heap-allocated data to prevent memory leaks.

// Free all posts for a user and remove them from postAVL
void deleteAllPosts(User* u) {
    Post* t = u->postHead;
    while (t) {
        postAVL.deleteKey(t->postID);
        Post* del = t; t = t->next; delete del;
    }
    u->postHead = nullptr;
}

// Free the circular story list for a user
void deleteAllStories(User* u) {
    if (!u->storyHead) return;
    Story* cur = u->storyHead, * start = cur;
    do { Story* del = cur; cur = cur->next; delete del; } while (cur != start);
    u->storyHead = nullptr;
}

// Remove this username from every other user's friend list (graph cleanup)
void removeFromGraph(string userName) {
    for (int i = 0; i < TABLE_SIZE; i++) {
        User* u = hashTable[i];
        while (u) {
            Edge* prev = nullptr, * e = u->friendList;
            while (e) {
                if (e->friendUserName == userName) {
                    if (prev) prev->next = e->next;
                    else      u->friendList = e->next;
                    Edge* del = e; e = e->next; delete del;
                }
                else { prev = e; e = e->next; }
            }
            u = u->next;
        }
    }
}

// Free all conversations and messages for a user
void deleteAllMessages(User* u) {
    Conversation* c = u->convList;
    while (c) {
        Message* m = c->top;
        while (m) { Message* del = m; m = m->next; delete del; }
        Conversation* del = c; c = c->next; delete del;
    }
    u->convList = nullptr;
}

// MODULE A: USER MANAGEMENT


// Register a new account -- validates username, email, and password
void registerUser() {
    string u, p, e, b;
    cout << endl << "--- CREATE ACCOUNT ---" << endl;
    cout << "Enter username : "; cin >> u;

    if (u.empty() || u.size() < 3) {
        cout << "  [Error] Username must be at least 3 characters." << endl; return;
    }
    if (searchUser(u)) {
        cout << "  [Error] Username '" << u << "' already exists!" << endl; return;
    }

    cout << "Enter email    : "; cin >> e;
    if (e.find('@') == string::npos || e.find('.') == string::npos) {
        cout << "  [Error] Invalid email. Must contain '@' and '.'." << endl; return;
    }

    cout << "Enter password : "; cin >> p;
    if (p.size() < 4) {
        cout << "  [Error] Password must be at least 4 characters." << endl; return;
    }

    cin.ignore();
    cout << "Bio            : "; getline(cin, b);
    if (!notEmpty(b)) b = "No bio yet.";

    int idx = hashFunction(u);
    User* n = new User(u, p, e, b);
    n->next = hashTable[idx];
    hashTable[idx] = n;

    userAVL.root = userAVL.insert(userAVL.root, u, 0);
    cout << "  Account created successfully! Please login." << endl;
}

// Log in by matching username and password against the hash table
void loginUser() {
    if (currentUser) {
        cout << "  [Error] Already logged in as '" << currentUser->userName << "'. Logout first." << endl;
        return;
    }
    string u, p;
    cout << endl << "=== LOGIN ===" << endl;
    cout << "Username: "; cin >> u;
    if (u.empty()) { cout << "  [Error] Username cannot be empty." << endl; return; }

    User* user = searchUser(u);
    if (!user) { cout << "  [Error] User '" << u << "' not found!" << endl; return; }

    cout << "Password: "; cin >> p;
    if (user->password != p) { cout << "  [Error] Incorrect password!" << endl; return; }

    currentUser = user;
    currentUser->lastActive = "Just now";
    cout << "  Welcome back, " << u << "!" << endl;
}

// Log out the currently active user
void logoutUser() {
    if (!currentUser) { cout << "  [Error] No user is logged in." << endl; return; }
    cout << "  " << currentUser->userName << " logged out successfully." << endl;
    currentUser = nullptr;
}

// Permanently delete the logged in user's account and all associated data
void deleteUser() {
    if (!currentUser) { cout << "  [Error] Not logged in!" << endl; return; }
    string confirm;
    cout << "  WARNING: This will permanently delete your account and all data." << endl;
    cout << "  Type 'yes' to confirm: ";
    cin >> confirm;
    if (confirm != "yes") { cout << "  Cancelled." << endl; return; }

    string uName = currentUser->userName;
    int idx = hashFunction(uName);

    // Free all data first, then unlink the user node from the hash table
    deleteAllPosts(currentUser);
    deleteAllStories(currentUser);
    deleteAllMessages(currentUser);
    removeFromGraph(uName);
    userAVL.deleteKey(uName);

    User* prev = nullptr, * cur = hashTable[idx];
    while (cur) {
        if (cur->userName == uName) {
            if (prev) prev->next = cur->next;
            else      hashTable[idx] = cur->next;
            delete cur; break;
        }
        prev = cur; cur = cur->next;
    }
    currentUser = nullptr;
    cout << "  Account '" << uName << "' deleted successfully." << endl;
}

// Print a summary of every user stored in the hash table
void displayAllUsers() {
    cout << endl << "===== ALL REGISTERED USERS =====" << endl;
    bool found = false;
    for (int i = 0; i < TABLE_SIZE; i++) {
        User* t = hashTable[i];
        while (t) {
            cout << "  Username    : " << t->userName
                << endl << "  Email       : " << t->email
                << endl << "  Bio         : " << t->bio
                << endl << "  Last Active : " << t->lastActive << endl << "  ---" << endl;
            found = true;
            t = t->next;
        }
    }
    if (!found) cout << "  No users registered yet." << endl;
}

// Search for a user by username and display their profile
void searchUserDisplay() {
    string name;
    cout << "Enter username to search: "; cin >> name;
    if (name.empty()) { cout << "  [Error] Username cannot be empty." << endl; return; }
    User* u = searchUser(name);
    if (!u) { cout << "  [Error] User '" << name << "' not found." << endl; return; }
    cout << endl << "  Username    : " << u->userName
        << endl << "  Email       : " << u->email
        << endl << "  Bio         : " << u->bio
        << endl << "  Last Active : " << u->lastActive << endl;
}
// MODULE B: GRAPH (Friendship Network)
// Users = nodes, friendships = undirected edges stored
// as adjacency lists. Supports BFS and DFS traversal.


// Array based queue used for BFS
struct BFSQueue {
    string data[200]; int front, rear;
    BFSQueue() { front = rear = 0; }
    bool isEmpty() { return front == rear; }
    void enqueue(string s) { if (rear < 200) data[rear++] = s; }
    string dequeue() { return data[front++]; }
};

// Array based stack used for DFS
struct DFSStack {
    string data[200]; int top;
    DFSStack() { top = -1; }
    bool isEmpty() { return top == -1; }
    void push(string s) { if (top < 199) data[++top] = s; }
    string pop() { return data[top--]; }
};

// Linear scan to check if a username is already in the visited array
bool isVisited(string* arr, int cnt, string val) {
    for (int i = 0; i < cnt; i++) if (arr[i] == val) return true;
    return false;
}

// BFS: visits users level by level starting from startUser
void BFS(string startUser) {
    if (startUser.empty()) { cout << "  [Error] Username cannot be empty." << endl; return; }
    User* start = searchUser(startUser);
    if (!start) { cout << "  [Error] User '" << startUser << "' not found." << endl; return; }

    cout << endl << " BFS from '" << startUser << " " << endl;
    string visited[200]; int vCnt = 0;
    BFSQueue q;
    q.enqueue(startUser);
    visited[vCnt++] = startUser;

    while (!q.isEmpty()) {
        string cur = q.dequeue();
        cout << "  Visited: " << cur << endl;
        User* u = searchUser(cur);
        if (!u) continue;
        Edge* e = u->friendList;
        while (e) {
            if (!isVisited(visited, vCnt, e->friendUserName)) {
                visited[vCnt++] = e->friendUserName;
                q.enqueue(e->friendUserName);
            }
            e = e->next;
        }
    }
    cout << "  BFS complete. " << vCnt << " user(s) visited." << endl;
}
// DFS: explores as deep as possible before backtracking
void DFS(string startUser) {
    if (startUser.empty()) { cout << "  [Error] Username cannot be empty." << endl; return; }
    User* start = searchUser(startUser);
    if (!start) { cout << "  [Error] User '" << startUser << "' not found." << endl; return; }

    cout << endl << "--- DFS from '" << startUser << "' ---" << endl;
    string visited[200]; int vCnt = 0;
    DFSStack stk;
    stk.push(startUser);

    while (!stk.isEmpty()) {
        string cur = stk.pop();
        if (isVisited(visited, vCnt, cur)) continue;
        visited[vCnt++] = cur;
        cout << "  Visited: " << cur << endl;
        User* u = searchUser(cur);
        if (!u) continue;
        Edge* e = u->friendList;
        while (e) {
            if (!isVisited(visited, vCnt, e->friendUserName))
                stk.push(e->friendUserName);
            e = e->next;
        }
    }
    cout << "  DFS complete. " << vCnt << " user(s) visited." << endl;
}
// Add a friend: creates an undirected edge on both sides
void addFriend() {
    string name;
    cout << "Enter friend username: "; cin >> name;
    if (name.empty()) { cout << "  [Error] Username cannot be empty." << endl; return; }
    if (name == currentUser->userName) {
        cout << "  [Error] You cannot add yourself as a friend!" << endl; return;
    }
    User* other = searchUser(name);
    if (!other) { cout << "  [Error] User '" << name << "' does not exist." << endl; return; }

    // Make sure they are not already friends
    Edge* check = currentUser->friendList;
    while (check) {
        if (check->friendUserName == name) {
            cout << "  [Error] Already friends with '" << name << "'." << endl; return;
        }
        check = check->next;
    }

    // Insert edge into both users' adjacency lists
    Edge* e1 = new Edge(name);
    e1->next = currentUser->friendList;
    currentUser->friendList = e1;

    Edge* e2 = new Edge(currentUser->userName);
    e2->next = other->friendList;
    other->friendList = e2;

    // Only notify the person who was added, not the one who added
    pushNotification(currentUser->userName + " added you as a friend!", name);
    cout << "  Friend '" << name << "' added successfully!" << endl;
}
// Remove a friend from the current user's adjacency list
void removeFriend() {
    string name;
    cout << "Enter friend username to remove: "; cin >> name;
    if (name.empty()) { cout << "  [Error] Username cannot be empty." << endl; return; }

    Edge* prev = nullptr, * cur = currentUser->friendList;
    while (cur) {
        if (cur->friendUserName == name) {
            if (prev) prev->next = cur->next;
            else      currentUser->friendList = cur->next;
            delete cur;
            cout << "  '" << name << "' removed from friends." << endl;
            return;
        }
        prev = cur; cur = cur->next;
    }
    cout << "  [Error] '" << name << "' is not in your friend list." << endl;
}
// Print all friends of the current user
void showFriends() {
    cout << endl << "--- FRIEND LIST of " << currentUser->userName << " ---" << endl;
    Edge* t = currentUser->friendList;
    if (!t) { cout << "  You have no friends yet." << endl; return; }
    int cnt = 0;
    while (t) { cout << "  " << ++cnt << ". " << t->friendUserName << endl; t = t->next; }
}
// MODULE C: POSTS
// Posts are stored in a doubly linked list per user.
// postAVL tracks each post's like count for analytics.

// Create a new post and append it to the end of the user's post list
void createPost() {
    string id, content;
    cout << endl << "=== CREATE POST ===" << endl;
    cout << "Enter post ID  : "; cin >> id;
    if (id.empty()) { cout << "  [Error] Post ID cannot be empty." << endl; return; }

    // Reject duplicate post IDs within the same user's posts
    Post* check = currentUser->postHead;
    while (check) {
        if (check->postID == id) {
            cout << "  [Error] Post ID '" << id << "' already exists." << endl; return;
        }
        check = check->next;
    }

    cin.ignore();
    cout << "Post content   : "; getline(cin, content);
    if (!notEmpty(content)) { cout << "  [Error] Post content cannot be empty." << endl; return; }

    Post* p = new Post(id, content, currentUser->userName);
    if (!currentUser->postHead) {
        currentUser->postHead = p;
    }
    else {
        Post* t = currentUser->postHead;
        while (t->next) t = t->next;
        t->next = p; p->prev = t;
    }

    // Register in postAVL with 0 likes; increment user activity score by 1
    postAVL.root = postAVL.insert(postAVL.root, id, 0);
    userAVL.root = userAVL.insert(userAVL.root, currentUser->userName, 1);

    pushNotification(currentUser->userName + " created a new post!", currentUser->userName);
    cout << "  Post created successfully!" << endl;
}

// Display all posts belonging to the current user
void viewPosts() {
    cout << endl << "=== YOUR POSTS ===" << endl;
    Post* t = currentUser->postHead;
    if (!t) { cout << "  You have no posts yet." << endl; return; }
    int cnt = 0;
    while (t) {
        cout << "  [" << ++cnt << "] ID: " << t->postID
            << " | Likes: " << t->likes << endl << "      " << t->content << endl;
        t = t->next;
    }
}

// Delete a specific post by ID from the current user's list
void deletePost() {
    string id;
    cout << "Enter post ID to delete: "; cin >> id;
    if (id.empty()) { cout << "  [Error] Post ID cannot be empty." << endl; return; }

    Post* t = currentUser->postHead;
    while (t) {
        if (t->postID == id) {
            if (t->prev) t->prev->next = t->next;
            else         currentUser->postHead = t->next;
            if (t->next) t->next->prev = t->prev;
            postAVL.deleteKey(id);
            delete t;
            cout << "  Post '" << id << "' deleted successfully." << endl;
            return;
        }
        t = t->next;
    }
    cout << "  [Error] Post '" << id << "' not found." << endl;
}

// Like a post owned by another user; updates both the post and postAVL
void likePost() {
    string owner, id;
    cout << "Enter post owner username: "; cin >> owner;
    if (owner.empty()) { cout << "  [Error] Owner username cannot be empty." << endl; return; }

    User* u = searchUser(owner);
    if (!u) { cout << "  [Error] User '" << owner << "' not found." << endl; return; }
    if (!u->postHead) { cout << "  [Error] User '" << owner << "' has no posts." << endl; return; }

    cout << "Enter post ID            : "; cin >> id;
    if (id.empty()) { cout << "  [Error] Post ID cannot be empty." << endl; return; }

    Post* t = u->postHead;
    while (t) {
        if (t->postID == id) {
            t->likes++;
            AVLNode* node = postAVL.search(id);
            if (node) postAVL.updateValue(id, t->likes);

            // Notify the post owner, not the person who liked
            pushNotification(currentUser->userName + " liked your post '" + id + "'!", owner);
            cout << "  Post liked! Total likes: " << t->likes << endl;
            return;
        }
        t = t->next;
    }
    cout << "  [Error] Post '" << id << "' not found under '" << owner << "'." << endl;
}

// Navigate posts with next/prev controls -- like scrolling a feed
void navigateFeed() {
    if (!currentUser->postHead) { cout << "  You have no posts to navigate." << endl; return; }

    Post* cur = currentUser->postHead;
    int ch = 0;
    do {
        cout << endl << "  ====== POST ======" << endl;
        cout << "  ID      : " << cur->postID << endl;
        cout << "  Content : " << cur->content << endl;
        cout << "  Likes   : " << cur->likes << endl;
        cout << "  1. Next    2. Prev    3. Exit feed" << endl << "  > ";
        if (!readInt(ch)) continue;
        if (ch == 1) { if (cur->next) cur = cur->next; else cout << "  Last post." << endl; }
        else if (ch == 2) { if (cur->prev) cur = cur->prev; else cout << "  First post." << endl; }
        else if (ch != 3)   cout << "  [Error] Enter 1, 2, or 3." << endl;
    } while (ch != 3);
}

// MODULE D: STORIES
// Each user has a circular linked list of stories.
// All users' stories are visible in the global feed.


// Add a story to the end of the current user's circular list
void addStory() {
    string s;
    cin.ignore();
    cout << "Story content: "; getline(cin, s);
    if (!notEmpty(s)) { cout << "  [Error] Story content cannot be empty." << endl; return; }

    Story* n = new Story(currentUser->userName, s);
    if (!currentUser->storyHead) {
        // First story: point to itself to form the circle
        currentUser->storyHead = n; n->next = n;
    }
    else {
        // Walk to the last node, then link the new one in before the head
        Story* t = currentUser->storyHead;
        while (t->next != currentUser->storyHead) t = t->next;
        t->next = n; n->next = currentUser->storyHead;
    }

    pushNotification(currentUser->userName + " added a new story!", currentUser->userName);
    cout << "  Story added successfully!" << endl;
}

// Show all stories from all users in the system
void viewStories() {
    cout << endl << "=== STORIES FEED ===" << endl;
    bool found = false;
    for (int i = 0; i < TABLE_SIZE; i++) {
        User* t = hashTable[i];
        while (t) {
            if (t->storyHead) {
                found = true;
                Story* s = t->storyHead;
                // Traverse the circular list until we return to the head
                do {
                    cout << "  [" << s->userName << "] " << s->storyContent << endl;
                    s = s->next;
                } while (s != t->storyHead);
            }
            t = t->next;
        }
    }
    if (!found) cout << "  No stories available." << endl;
}
// MODULE F: ANALYTICS & RANKING
// AVL trees power all ranking features.
// userAVL sorts by activity postAVL sorts by likes.

void showRanking() {
    int ch;
    do {
        cout << endl << "===== ANALYTICS & RANKING =====" << endl;
        cout << "1. Top K Active Users" << endl << "2. Top K Liked Posts" << endl;
        cout << "3. All Users Sorted" << endl << "4. All Posts Sorted" << endl;
        cout << "5. Search User in AVL" << endl << "6. Search Post in AVL" << endl;
        cout << "7. Range Query (Users)" << endl << "8. Range Query (Posts)" << endl;
        cout << "9. Back" << endl << "> ";
        if (!readInt(ch)) continue;

        if (ch == 1 || ch == 2) {
            int k; cout << "  Enter K: ";
            if (!readInt(k)) continue;
            if (k <= 0) { cout << "  [Error] K must be > 0." << endl; continue; }
            (ch == 1 ? userAVL : postAVL).getTopK(k);
        }
        else if (ch == 3) { cout << endl << "--- Sorted Users ---" << endl; userAVL.showSorted(); }
        else if (ch == 4) { cout << endl << "--- Sorted Posts ---" << endl; postAVL.showSorted(); }
        else if (ch == 5) {
            string key; cout << "  Username: "; cin >> key;
            AVLNode* n = userAVL.search(key);
            if (n) cout << "  Found: " << n->key << " | Activity: " << n->value << endl;
            else   cout << "  [Error] Not found in AVL." << endl;
        }
        else if (ch == 6) {
            string key; cout << "  Post ID: "; cin >> key;
            AVLNode* n = postAVL.search(key);
            if (n) cout << "  Found: " << n->key << " | Likes: " << n->value << endl;
            else   cout << "  [Error] Not found in AVL." << endl;
        }
        else if (ch == 7 || ch == 8) {
            int mn, mx;
            cout << "  Min: "; if (!readInt(mn)) continue;
            cout << "  Max: "; if (!readInt(mx)) continue;
            if (mn > mx) { cout << "  [Error] Min cannot be greater than Max." << endl; continue; }
            (ch == 7 ? userAVL : postAVL).rangeQuery(mn, mx);
        }
        else if (ch != 9) { cout << "  [Error] Invalid option. Enter 1-9." << endl; }
    } while (ch != 9);
}
// MODULE G: MESSAGING
// Each pair of users shares a Conversation object.
// Messages are pushed onto a stack; latest is on top.
// Both sender and receiver get their own copy.


// Return an existing conversation or create a new one for this pair
Conversation* findOrCreateConv(User* u, string other) {
    Conversation* c = u->convList;
    while (c) { if (c->otherUser == other) return c; c = c->next; }
    Conversation* newC = new Conversation(other);
    newC->next = u->convList;
    u->convList = newC;
    return newC;
}

// Send a message: pushed onto both sender's and receiver's conversation stacks
void sendMessage() {
    string toUser, text;
    cout << "Send to        : "; cin >> toUser;
    if (toUser.empty()) { cout << "  [Error] Recipient cannot be empty." << endl; return; }
    if (toUser == currentUser->userName) {
        cout << "  [Error] Cannot message yourself." << endl; return;
    }
    User* receiver = searchUser(toUser);
    if (!receiver) { cout << "  [Error] User '" << toUser << "' not found." << endl; return; }

    cin.ignore();
    cout << "Message        : "; getline(cin, text);
    if (!notEmpty(text)) { cout << "  [Error] Message cannot be empty." << endl; return; }

    // Push onto sender's stack
    Message* msg = new Message(currentUser->userName, toUser, text, "NOW");
    Conversation* sc = findOrCreateConv(currentUser, toUser);
    msg->next = sc->top; sc->top = msg;

    // Push a copy onto receiver's stack
    Message* copy = new Message(currentUser->userName, toUser, text, "NOW");
    Conversation* rc = findOrCreateConv(receiver, currentUser->userName);
    copy->next = rc->top; rc->top = copy;

    // Only the receiver gets the notification
    pushNotification(currentUser->userName + " sent you a message!", toUser);
    cout << "  Message sent to '" << toUser << "'!" << endl;
}

// View the top (most recent) message in a conversation without removing it
void viewLatestMessage() {
    string other;
    cout << "Conversation with: "; cin >> other;
    if (other.empty()) { cout << "  [Error] Username cannot be empty." << endl; return; }

    Conversation* c = currentUser->convList;
    while (c) {
        if (c->otherUser == other) {
            if (c->top)
                cout << "  Latest -> [" << c->top->fromUser << "]: "
                << c->top->text << endl;
            else cout << "  No messages." << endl;
            return;
        }
        c = c->next;
    }
    cout << "  [Error] No conversation with '" << other << "'." << endl;
}

// Pop (remove) the most recent message from the top of a conversation stack
void popMessage() {
    string other;
    cout << "Pop from conversation with: "; cin >> other;
    if (other.empty()) { cout << "  [Error] Username cannot be empty." << endl; return; }

    Conversation* c = currentUser->convList;
    while (c) {
        if (c->otherUser == other) {
            if (!c->top) { cout << "  [Error] No messages to pop." << endl; return; }
            Message* del = c->top;
            cout << "  Popped: [" << del->fromUser << "]: " << del->text << endl;
            c->top = c->top->next;
            delete del;
            return;
        }
        c = c->next;
    }
    cout << "  [Error] No conversation with '" << other << "'." << endl;
}

// Print the full message history of a conversation (latest message first)
void displayConversation() {
    string other;
    cout << "Full conversation with: "; cin >> other;
    if (other.empty()) { cout << "  [Error] Username cannot be empty." << endl; return; }

    Conversation* c = currentUser->convList;
    while (c) {
        if (c->otherUser == other) {
            if (!c->top) { cout << "  No messages yet." << endl; return; }
            cout << endl << "--- Conversation with " << other << " (latest first) ---" << endl;
            Message* m = c->top;
            int cnt = 0;
            while (m) {
                cout << "  [" << m->fromUser << " -> " << m->toUser << "]: "
                    << m->text << endl;
                m = m->next; cnt++;
            }
            cout << "  Total: " << cnt << " message(s)." << endl;
            return;
        }
        c = c->next;
    }
    cout << "  [Error] No conversation with '" << other << "'." << endl;
}

// SUB MENUS
void userManagementMenu() {
    int ch;
    do {
        cout << endl << "=== USER MANAGEMENT ===" << endl;
        if (currentUser) cout << "  Logged in as: " << currentUser->userName << endl;
        else             cout << "  Not logged in" << endl;
        cout << "1. Register" << endl << "2. Login" << endl << "3. Delete My Account" << endl;
        cout << "4. Search User" << endl << "5. Display All Users" << endl << "6. Back" << endl << "> ";
        if (!readInt(ch)) continue;
        switch (ch) {
        case 1: registerUser();      break;
        case 2: loginUser();         break;
        case 3: deleteUser();        break;
        case 4: searchUserDisplay(); break;
        case 5: displayAllUsers();   break;
        case 6: break;
        default: cout << "  [Error] Invalid option. Enter 1-6." << endl;
        }
    } while (ch != 6);
}

void friendMenu() {
    int ch;
    do {
        cout << endl << "=== SOCIAL NETWORK ===" << endl;
        cout << "1. Add Friend" << endl << "2. Remove Friend" << endl << "3. View Friends" << endl;
        cout << "4. BFS Traversal" << endl << "5. DFS Traversal" << endl << "6. Back" << endl << "> ";
        if (!readInt(ch)) continue;
        string s;
        switch (ch) {
        case 1: addFriend();    break;
        case 2: removeFriend(); break;
        case 3: showFriends();  break;
        case 4: cout << "BFS start user: "; cin >> s; BFS(s); break;
        case 5: cout << "DFS start user: "; cin >> s; DFS(s); break;
        case 6: break;
        default: cout << "  [Error] Invalid option. Enter 1-6." << endl;
        }
    } while (ch != 6);
}

void postMenu() {
    int ch;
    do {
        cout << endl << "=== POSTS & FEED ===" << endl;
        cout << "1. Create Post" << endl << "2. Delete Post" << endl << "3. View My Posts" << endl;
        cout << "4. Navigate Feed" << endl << "5. Like a Post" << endl << "6. Back" << endl << "> ";
        if (!readInt(ch)) continue;
        switch (ch) {
        case 1: createPost();   break;
        case 2: deletePost();   break;
        case 3: viewPosts();    break;
        case 4: navigateFeed(); break;
        case 5: likePost();     break;
        case 6: break;
        default: cout << "  [Error] Invalid option. Enter 1-6." << endl;
        }
    } while (ch != 6);
}

void storyMenu() {
    int ch;
    do {
        cout << endl << "=== STORIES ===" << endl;
        cout << "1. Add Story" << endl << "2. View Stories" << endl << "3. Back" << endl << "> ";
        if (!readInt(ch)) continue;
        if (ch == 1) addStory();
        else if (ch == 2) viewStories();
        else if (ch != 3) cout << "  [Error] Enter 1, 2, or 3." << endl;
    } while (ch != 3);
}

void notificationMenu() {
    int ch;
    do {
        cout << endl << "=== NOTIFICATIONS ===" << endl;
        cout << "1. View All" << endl << "2. Process Next" << endl << "3. Peek Next" << endl << "4. Back" << endl << "> ";
        if (!readInt(ch)) continue;
        if (ch == 1)      showNotifications();
        else if (ch == 2) popNotification();
        else if (ch == 3) peekNotification();
        else if (ch != 4) cout << "  [Error] Enter 1-4." << endl;
    } while (ch != 4);
}

void messagingMenu() {
    int ch;
    do {
        cout << endl << "=== MESSAGING ===" << endl;
        cout << "1. Send Message" << endl << "2. View Latest Message" << endl;
        cout << "3. Pop Message" << endl << "4. View Conversation" << endl << "5. Back" << endl << "> ";
        if (!readInt(ch)) continue;
        switch (ch) {
        case 1: sendMessage();         break;
        case 2: viewLatestMessage();   break;
        case 3: popMessage();          break;
        case 4: displayConversation(); break;
        case 5: break;
        default: cout << "  [Error] Enter 1-5." << endl;
        }
    } while (ch != 5);
}
// MAIN MENU
// Adapts based on login status:
//   - Logged in: full access to all modules
//   - Not logged in: only register/login visible
void mainMenu() {
    int ch;
    do {
        cout << endl << "================ MAIN MENU =================" << endl;
        if (currentUser) {
            cout << "  Logged in as: " << currentUser->userName << endl;
            cout << "_________________________________________________" << endl;
            cout << "1. User Management" << endl;
            cout << "2. Social Network (Graph)" << endl;
            cout << "3. Posts & Feed" << endl;
            cout << "4. Stories" << endl;
            cout << "5. Notifications" << endl;
            cout << "6. Analytics & Ranking" << endl;
            cout << "7. Messaging" << endl;
            cout << "8. Logout" << endl;
            cout << "9. Exit" << endl << "> ";
            if (!readInt(ch)) continue;
            switch (ch) {
            case 1: userManagementMenu(); break;
            case 2: friendMenu();         break;
            case 3: postMenu();           break;
            case 4: storyMenu();          break;
            case 5: notificationMenu();   break;
            case 6: showRanking();        break;
            case 7: messagingMenu();      break;
            case 8: logoutUser();         break;
            case 9: cout << "  Goodbye!" << endl; break;
            default: cout << "  [Error] Enter 1-9." << endl;
            }
        }
        else {
            // Guest mode: only registration and login are accessible
            cout << "  Not logged in" << endl;
            cout << "_________________________________________________" << endl;
            cout << "1. User Management (Register / Login)" << endl;
            cout << "9. Exit" << endl << "> ";
            if (!readInt(ch)) continue;
            if (ch == 1) userManagementMenu();
            else if (ch == 9) cout << "  Goodbye!" << endl;
            else              cout << "  [Error] Please register or login first." << endl;
        }
    } while (ch != 9);
}

// MAIN  program entry point

int main() {
    init();
    cout << "_________________________________________________" << endl;
    cout << "   Console Social Media Platform" << endl;
    cout << "_________________________________________________" << endl;
    mainMenu();
    system("pause");
    return 0;
}